Timelines are 16-step skeletons used as probability maps.
