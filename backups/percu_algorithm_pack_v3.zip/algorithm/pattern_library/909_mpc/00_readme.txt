909/MPC discipline: accents and velocity curves define groove. shuffle must be stable.
