Influence tags map to sequencer decisions and target biases.
